package com.example.mad_practical11_20012011021

import android.content.Context
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.*

class Note ( var title:String, var subTitle:String, var Description:String, var modifiedTime:String, var reminderTime:Long,var isReminderEnable:Boolean,var isReminder:Boolean ) {
    var id = noteIdGenerator()

    fun isValid() : Boolean{
        if(title.isEmpty() || Description.isEmpty())
            return false
        return true
    }



    fun getReminderText() :String
    {
        return "Remainder: "+(SimpleDateFormat("MM,dd yyyy hh:mm a") as DateFormat).format(
            Date(reminderTime)
        )
    }

    fun saveNote(context: Context)
    {
        if (isReminder){
            setRemider(context,this)

        }
    }

    fun getHour():Int{
        val cal = Calendar.getInstance()
        cal.time = Date(reminderTime)
        return cal[Calendar.HOUR_OF_DAY]

    }

    fun getMinute():Int{
        val cal = Calendar.getInstance()
        cal.time = Date(reminderTime)
        return cal[Calendar.MINUTE]
    }

    fun calcReminder(){
        if(reminderTime < System.currentTimeMillis())
            isReminder = false
    }

    override fun toString(): String {
        return "$id\n"+title+"\n"+subTitle+"\n"+Description+"\nReminder:$isReminder" + "\n"+getReminderText()
    }
    companion object {
        var idNote = 0
        fun noteIdGenerator():Int
        {
            idNote++
            return idNote
        }
        val REMINDER_REQUEST_CODE = 1808
        val NOTE_ID_KEY = "ID"
        val NOTE_TITLE_KEY = "Title"
        val NOTE_SUBTITLE_KEY = "SubTitle"
        val NOTE_DESCRIPTION_KEY = "Description"
        val NOTE_MODIFIED_TIME_KEY = "ModifiedTime"
        val NOTE_REMAINDER_TIME_KEY = "REMINDERTIME"

        fun getCurrentDateTime(): String{
            val cal = Calendar.getInstance()
            val df : DateFormat = SimpleDateFormat("MM,dd yyyy hh:mm a")
            return df.format(cal.time)
        }

        fun getMills(hour:Int,min:Int):Long {
            val setcalender = Calendar.getInstance()
            setcalender[Calendar.HOUR_OF_DAY]= hour
            setcalender[Calendar.MINUTE]=min
            setcalender[Calendar.SECOND]=0
            return setcalender.timeInMillis
        }

    }
    fun setRemider(context: Context,note: Note)
    {

    }



}