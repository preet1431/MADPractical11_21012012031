package com.example.madpractical11_21012012031

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class Alarmbroadcastreceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
       if(intent != null && context !=null){
           val note = note()
           note.id = intent.getIntExtra(note.note_id_key,-1)

       }    }
}